web-skeleton
============

Generator of static html/css/js code tree.

Based on:
    - `yuicompressor <https://pypi.python.org/pypi/yuicompressor>`_
    - `mako <https://pypi.python.org/pypi/Mako>`_
    - `webassets <https://pypi.python.org/pypi/webassets>`_


Install
=======

Install with::

    easy_install web-skeleton3


.. warning:: remember install::

    sudo apt-get install ruby-compass
    sudo easy_install -U scour

License
-------

Copyright (c) 2017,2019 Niyamaka.

`web-skeleton3` is released under terms of the
`MIT License <http://www.opensource.org/licenses/mit-license>`_.
