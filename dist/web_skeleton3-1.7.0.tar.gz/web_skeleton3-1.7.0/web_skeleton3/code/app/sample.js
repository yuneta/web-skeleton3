/**
 *  Sample
 */

(function() {
    var sample;
}());

